from __future__ import annotations

import ast
from pathlib import Path
import re
import subprocess
import sys
from unittest.mock import patch

import yaml


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from gherkin_contract import ContractError, _assert_responses, load_contract, run_live  # noqa: E402

RUNNER = REPO_ROOT / "scripts" / "gherkin_contract.py"
FEATURES = REPO_ROOT / "specification" / "features"
BINDINGS = REPO_ROOT / "specification" / "gherkin-bindings.yaml"

SMOKE_SCENARIOS = [
    "Create a quote on a seeded peak-season lane",
    "Retrieve a stored quote",
    "Validate whether a stored quote can still be booked",
    "Revoke an issued quote and block booking reuse",
]
PUBLIC_LIFECYCLE_SCENARIOS = [
    "Validate rate coverage before requesting a quote",
    "Plan equipment availability with explicit substitution suggestions",
    "Persist quote lifecycle events in the outbox",
    "Request a quote for a seeded schedule without an effective rate",
    "Reprice an existing quote and explain the commercial variance",
    "Return multiple commercial options for one quote request",
    "Bound alternative options on quote creation",
]
COMMERCIAL_ADMIN_SCENARIOS = [
    "Create, update, and activate a managed rate-table version",
    "Create, update, and activate a managed surcharge-rule version",
    "Require platform bearer authorization for commercial admin changes",
    "Check Equipments service connectivity",
    "Record an audit trail for managed commercial changes",
    "Publish managed commercial changes to the outbox",
    "Replay outbox events for a named downstream consumer",
    "Analyze quote impact for schedule or contract changes",
    "Preview quote pricing with draft managed commercial data",
]
AUTH_DEPLOYMENT_BOUNDARY_SCENARIOS = [
    "Accept Users-issued Quotes-audience platform tokens for protected operations",
    "Accept gateway-issued Quotes-audience platform tokens for protected operations",
    "Reject missing or invalid protected-route bearer tokens",
    "Reject valid tokens without the required Quotes scope",
    "Resolve role=admin compatibility before implementation",
    "Keep web-page bearer propagation inside the gateway boundary",
    "Verify Azure platform auth settings before deployment sign-off",
    "Keep Booking on public quote validation and Equipments on diagnostics",
]
CUSTOMER_OPERATIONS_SCENARIOS = [
    "Replay a quote request with an idempotency key",
    "List stored quotes for a customer portfolio",
    "Read a quote lifecycle timeline",
]
EXECUTABLE_SCENARIOS = [
    *SMOKE_SCENARIOS,
    *PUBLIC_LIFECYCLE_SCENARIOS,
    *COMMERCIAL_ADMIN_SCENARIOS,
    *AUTH_DEPLOYMENT_BOUNDARY_SCENARIOS,
    *CUSTOMER_OPERATIONS_SCENARIOS,
]


def _scenario_file_name(index: int, scenario_name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", scenario_name.lower()).strip("-")
    return f"{index:03d}-{slug}.feature"


def _feature_scenario_names(feature_file: Path) -> list[str]:
    names: list[str] = []
    for raw_line in feature_file.read_text().splitlines():
        line = raw_line.strip()
        if line.startswith("Scenario Outline:"):
            names.append(line.removeprefix("Scenario Outline:").strip())
        elif line.startswith("Scenario:"):
            names.append(line.removeprefix("Scenario:").strip())
    return names


def _run_contract_command(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(RUNNER), *args],
        cwd=REPO_ROOT,
        text=True,
        capture_output=True,
        check=False,
    )


def test_contract_runner_has_no_service_or_pytest_imports() -> None:
    tree = ast.parse(RUNNER.read_text())
    forbidden_roots = {"app", "db", "seed", "tests", "pytest"}
    imports: set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name.split(".", maxsplit=1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module.split(".", maxsplit=1)[0])

    assert imports.isdisjoint(forbidden_roots)


def test_feature_catalog_uses_one_scenario_per_file_in_binding_order() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    binding_scenarios = list(document["scenarios"])
    feature_files = sorted(FEATURES.glob("*.feature"))

    assert [path.name for path in feature_files] == [
        _scenario_file_name(index, scenario)
        for index, scenario in enumerate(binding_scenarios, start=1)
    ]

    actual_scenarios: list[str] = []
    for feature_file in feature_files:
        feature_count = sum(
            1
            for raw_line in feature_file.read_text().splitlines()
            if raw_line.strip().startswith("Feature:")
        )
        assert feature_count == 1, f"{feature_file.name} must contain exactly one Feature heading"

        scenarios = _feature_scenario_names(feature_file)
        assert len(scenarios) == 1, f"{feature_file.name} must contain exactly one scenario"
        actual_scenarios.extend(scenarios)

    assert actual_scenarios == binding_scenarios


def test_contract_cli_lists_scenarios_from_feature_files() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    assert sorted(path.name for path in FEATURES.glob("*.feature")) == [
        _scenario_file_name(index, scenario)
        for index, scenario in enumerate(document["scenarios"], start=1)
    ]

    result = _run_contract_command("list", "--features", str(FEATURES), "--bindings", str(BINDINGS))

    assert result.returncode == 0, result.stderr
    for scenario in SMOKE_SCENARIOS:
        assert scenario in result.stdout
    assert "44 scenarios" in result.stdout


def test_contract_cli_validates_binding_coverage() -> None:
    result = _run_contract_command("validate", "--features", str(FEATURES), "--bindings", str(BINDINGS))

    assert result.returncode == 0, result.stderr
    assert "gherkin-contract: verified 44 scenarios" in result.stdout
    assert "31 executable bindings" in result.stdout
    for scenario in EXECUTABLE_SCENARIOS:
        assert scenario in result.stdout


def test_contract_cli_dry_runs_smoke_group_without_service() -> None:
    result = _run_contract_command(
        "run",
        "--features",
        str(FEATURES),
        "--bindings",
        str(BINDINGS),
        "--profile",
        "local",
        "--group",
        "smoke",
        "--dry-run",
    )

    assert result.returncode == 0, result.stderr
    assert "dry-run: local smoke" in result.stdout
    for scenario in SMOKE_SCENARIOS:
        assert f"DRY-RUN {scenario}" in result.stdout


def test_smoke_bindings_define_profiles_fixtures_actions_and_assertions() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    scenarios = document["scenarios"]

    for scenario in SMOKE_SCENARIOS:
        binding = scenarios[scenario]
        assert binding["group"] == "smoke"
        assert "local" in binding["profiles"]
        assert binding["fixtures"]
        assert binding["actions"]
        assert binding["assertions"]


def test_public_lifecycle_bindings_define_executable_black_box_steps() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    scenarios = document["scenarios"]

    for scenario in PUBLIC_LIFECYCLE_SCENARIOS:
        binding = scenarios[scenario]
        assert binding["status"] == "executable"
        assert "local" in binding["profiles"]
        assert "fixtures" in binding
        assert binding["fixtures"] or binding.get("requires_env")
        assert binding["actions"]
        assert binding["assertions"]


def test_public_lifecycle_bindings_dry_run_without_service() -> None:
    for scenario in PUBLIC_LIFECYCLE_SCENARIOS:
        result = _run_contract_command(
            "run",
            "--features",
            str(FEATURES),
            "--bindings",
            str(BINDINGS),
            "--profile",
            "local",
            "--scenario",
            scenario,
            "--dry-run",
        )

        assert result.returncode == 0, result.stderr
        assert f"DRY-RUN {scenario}" in result.stdout


def test_lifecycle_env_gate_reports_env_name_not_description() -> None:
    result = _run_contract_command(
        "run",
        "--features",
        str(FEATURES),
        "--bindings",
        str(BINDINGS),
        "--profile",
        "local",
        "--scenario",
        "Persist quote lifecycle events in the outbox",
        "--dry-run",
    )

    assert result.returncode == 0, result.stderr
    assert "QUOTES_CONTRACT_EXPIRED_QUOTE_ID" in result.stdout
    assert "Pre-seeded quote" not in result.stdout


def test_repricing_binding_is_isolated_from_alternative_option_quotes() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    fixtures = document["fixtures"]
    repricing_binding = document["scenarios"]["Reprice an existing quote and explain the commercial variance"]
    repricing_quote = fixtures["repricing_original_quote_request"]
    repricing_equipment = {item["type"] for item in repricing_quote["equipment"]}
    alternative_quotes = [
        fixture
        for fixture in fixtures.values()
        if isinstance(fixture, dict)
        and fixture.get("scheduleId") == repricing_quote["scheduleId"]
        and fixture.get("includeAlternativeOptions") is True
    ]
    alternative_equipment = {item["type"] for quote in alternative_quotes for item in quote["equipment"]}

    assert repricing_equipment.isdisjoint(alternative_equipment)
    assert fixtures["repricing_rate_table_request"]["equipmentType"] not in alternative_equipment
    assert all(action["path"] != "/admin/surcharge-rules" for action in repricing_binding["actions"])


def test_lifecycle_binding_asserts_created_and_expired_events_for_same_quote() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    binding = document["scenarios"]["Persist quote lifecycle events in the outbox"]
    actions_by_name = {action["name"]: action for action in binding["actions"]}

    assert "create_quote" not in actions_by_name
    assert actions_by_name["materialize_expired_quote"]["save"] == {"quote_id": "$.id"}
    assert "{quote_id}" in actions_by_name["list_created_events"]["path"]
    assert "{quote_id}" in actions_by_name["list_expired_events"]["path"]

    same_quote_assertions = [
        assertion
        for assertion in binding["assertions"]
        if assertion.get("json_equals_state") == "quote_id"
    ]

    assert {
        (assertion["action"], assertion["path"])
        for assertion in same_quote_assertions
    } == {
        ("list_created_events", "$.events.0.aggregateId"),
        ("list_created_events", "$.events.0.payload.quoteId"),
        ("list_expired_events", "$.events.0.aggregateId"),
        ("list_expired_events", "$.events.0.payload.quoteId"),
    }


def test_commercial_admin_bindings_define_executable_black_box_steps() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    scenarios = document["scenarios"]

    for scenario in COMMERCIAL_ADMIN_SCENARIOS:
        binding = scenarios[scenario]
        assert binding["status"] == "executable"
        assert "local" in binding["profiles"]
        assert binding["actions"]
        assert binding["assertions"]


def test_commercial_admin_groups_dry_run_without_service() -> None:
    for group in ["admin-commercial", "auth", "diagnostics"]:
        result = _run_contract_command(
            "run",
            "--features",
            str(FEATURES),
            "--bindings",
            str(BINDINGS),
            "--profile",
            "local",
            "--group",
            group,
            "--dry-run",
        )

        assert result.returncode == 0, result.stderr
        assert f"dry-run: local {group}" in result.stdout


def test_azure_profile_resolves_auth_gates_to_azure_token_env_names() -> None:
    result = _run_contract_command(
        "run",
        "--features",
        str(FEATURES),
        "--bindings",
        str(BINDINGS),
        "--profile",
        "azure",
        "--scenario",
        "Require platform bearer authorization for commercial admin changes",
        "--dry-run",
    )

    assert result.returncode == 0, result.stderr
    assert "QUOTES_CONTRACT_AZURE_ADMIN_TOKEN" in result.stdout
    assert "QUOTES_CONTRACT_AZURE_APPROVER_TOKEN" in result.stdout
    assert "QUOTES_CONTRACT_ADMIN_TOKEN" not in result.stdout
    assert "QUOTES_CONTRACT_APPROVER_TOKEN" not in result.stdout


def test_azure_live_run_uses_azure_token_env_gates(monkeypatch, capsys) -> None:
    monkeypatch.delenv("QUOTES_CONTRACT_ADMIN_TOKEN", raising=False)
    monkeypatch.delenv("QUOTES_CONTRACT_APPROVER_TOKEN", raising=False)
    monkeypatch.setenv("QUOTES_CONTRACT_AZURE_BASE_URL", "http://quotes.azure.test")
    monkeypatch.setenv("QUOTES_CONTRACT_AZURE_ADMIN_TOKEN", "azure-admin")
    monkeypatch.setenv("QUOTES_CONTRACT_AZURE_APPROVER_TOKEN", "azure-approve")

    contract = load_contract(FEATURES, BINDINGS)
    scenario_name = "Require platform bearer authorization for commercial admin changes"
    responses = {
        "reject_missing_token": (401, {}),
        "reject_wrong_scope": (403, {}),
        "accept_admin_token": (201, {"createdBy": "pricing.ops@quotes"}),
    }
    token_envs_seen = []

    def fake_execute_action(action, fixtures, token_envs, base_url, timeout, state):
        token_envs_seen.append(dict(token_envs))
        return responses[action["name"]]

    with patch("gherkin_contract._execute_action", side_effect=fake_execute_action):
        run_live(contract, [scenario_name], "azure")

    output = capsys.readouterr().out
    assert "GATED" not in output
    assert token_envs_seen
    assert all(token_envs["admin"] == "QUOTES_CONTRACT_AZURE_ADMIN_TOKEN" for token_envs in token_envs_seen)
    assert all(token_envs["approve"] == "QUOTES_CONTRACT_AZURE_APPROVER_TOKEN" for token_envs in token_envs_seen)


def test_diagnostics_binding_reports_external_profile_gate() -> None:
    result = _run_contract_command(
        "run",
        "--features",
        str(FEATURES),
        "--bindings",
        str(BINDINGS),
        "--profile",
        "local",
        "--scenario",
        "Check Equipments service connectivity",
        "--dry-run",
    )

    assert result.returncode == 0, result.stderr
    assert "requires-env:" in result.stdout
    assert "QUOTES_CONTRACT_EQUIPMENTS_SERVICE_CONFIGURED" in result.stdout


def test_auth_deployment_boundary_bindings_define_runnable_results() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    scenarios = document["scenarios"]

    for scenario in AUTH_DEPLOYMENT_BOUNDARY_SCENARIOS:
        binding = scenarios[scenario]
        assert binding["status"] == "executable"
        assert not binding["binding"].startswith("planned.")
        assert binding["actions"]
        assert binding["assertions"]

    assert scenarios["Verify Azure platform auth settings before deployment sign-off"]["profiles"] == ["azure"]
    assert "QUOTES_CONTRACT_AZURE_AUTH_SETTINGS_VERIFIED" in set(
        scenarios["Verify Azure platform auth settings before deployment sign-off"]["requires_env"].values()
    )


def test_auth_deployment_boundary_dry_runs_show_profile_gates() -> None:
    for scenario in AUTH_DEPLOYMENT_BOUNDARY_SCENARIOS:
        result = _run_contract_command(
            "run",
            "--features",
            str(FEATURES),
            "--bindings",
            str(BINDINGS),
            "--profile",
            "azure" if scenario == "Verify Azure platform auth settings before deployment sign-off" else "local",
            "--scenario",
            scenario,
            "--dry-run",
        )

        assert result.returncode == 0, result.stderr
        assert f"DRY-RUN {scenario}" in result.stdout

    azure_result = _run_contract_command(
        "run",
        "--features",
        str(FEATURES),
        "--bindings",
        str(BINDINGS),
        "--profile",
        "azure",
        "--scenario",
        "Verify Azure platform auth settings before deployment sign-off",
        "--dry-run",
    )

    assert "QUOTES_CONTRACT_AZURE_AUTH_SETTINGS_VERIFIED" in azure_result.stdout


def test_customer_operations_bindings_define_executable_black_box_steps() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    scenarios = document["scenarios"]

    for scenario in CUSTOMER_OPERATIONS_SCENARIOS:
        binding = scenarios[scenario]
        assert binding["status"] == "executable"
        assert binding["group"] == "customer-operations"
        assert "local" in binding["profiles"]
        assert binding["actions"]
        assert binding["assertions"]


def test_customer_operations_group_dry_runs_without_service() -> None:
    result = _run_contract_command(
        "run",
        "--features",
        str(FEATURES),
        "--bindings",
        str(BINDINGS),
        "--profile",
        "local",
        "--group",
        "customer-operations",
        "--dry-run",
    )

    assert result.returncode == 0, result.stderr
    assert "dry-run: local customer-operations" in result.stdout
    for scenario in CUSTOMER_OPERATIONS_SCENARIOS:
        assert f"DRY-RUN {scenario}" in result.stdout


def test_idempotency_binding_sends_replay_key_as_a_request_header() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    binding = document["scenarios"]["Replay a quote request with an idempotency key"]
    quote_actions = [
        action
        for action in binding["actions"]
        if action["name"] in {"create_quote", "replay_quote"}
    ]

    assert quote_actions
    assert all(action["headers"] == {"Idempotency-Key": "{idempotency_key}"} for action in quote_actions)


def test_azure_auth_settings_live_run_gates_when_signoff_env_is_absent(monkeypatch, capsys) -> None:
    monkeypatch.delenv("QUOTES_CONTRACT_AZURE_AUTH_SETTINGS_VERIFIED", raising=False)

    contract = load_contract(FEATURES, BINDINGS)
    run_live(
        contract,
        ["Verify Azure platform auth settings before deployment sign-off"],
        "azure",
    )

    output = capsys.readouterr().out
    assert "GATED Verify Azure platform auth settings before deployment sign-off" in output
    assert "QUOTES_CONTRACT_AZURE_AUTH_SETTINGS_VERIFIED" in output


def test_azure_auth_settings_live_run_passes_when_signoff_envs_are_supplied(monkeypatch, capsys) -> None:
    for env_name in [
        "QUOTES_CONTRACT_AZURE_AUTH_SETTINGS_VERIFIED",
        "QUOTES_CONTRACT_AZURE_PUBLIC_QUOTE_CHECKED",
        "QUOTES_CONTRACT_AZURE_ADMIN_ROUTE_CHECKED",
        "QUOTES_CONTRACT_AZURE_APPROVAL_ROUTE_CHECKED",
        "QUOTES_CONTRACT_AZURE_EQUIPMENTS_AUDIENCE_REJECTION_CHECKED",
    ]:
        monkeypatch.setenv(env_name, "true")

    contract = load_contract(FEATURES, BINDINGS)
    run_live(
        contract,
        ["Verify Azure platform auth settings before deployment sign-off"],
        "azure",
    )

    output = capsys.readouterr().out
    assert "RUN Verify Azure platform auth settings before deployment sign-off" in output
    assert "GATED" not in output


def test_smoke_create_quote_assertions_match_created_response() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    scenarios = document["scenarios"]

    for scenario in SMOKE_SCENARIOS:
        binding = scenarios[scenario]
        create_quote_status_assertions = [
            assertion
            for assertion in binding["assertions"]
            if assertion.get("action") == "create_quote" and "status" in assertion
        ]

        assert create_quote_status_assertions == [{"action": "create_quote", "status": 201}]


def test_create_quote_smoke_binding_asserts_creation_response_fields_only() -> None:
    document = yaml.safe_load(BINDINGS.read_text())
    binding = document["scenarios"]["Create a quote on a seeded peak-season lane"]

    create_quote_fields = [
        assertion["json_field"]
        for assertion in binding["assertions"]
        if assertion.get("action") == "create_quote" and "json_field" in assertion
    ]

    assert create_quote_fields == ["$.id", "$.quoteReference"]


def test_contract_assertions_can_check_nested_option_lists_and_missing_fields() -> None:
    _assert_responses(
        "Bound alternative options on quote creation",
        [
            {
                "action": "create_quote",
                "path": "$.options.alternatives.0.pricingBasis",
                "json_equals": "PUBLIC_TARIFF",
            },
            {
                "action": "create_quote",
                "json_missing": "$.options.alternatives.1",
            },
            {
                "action": "create_quote",
                "json_missing": "$.options.unused",
            },
        ],
        {
            "create_quote": (
                201,
                {
                    "options": {
                        "alternatives": [
                            {
                                "pricingBasis": "PUBLIC_TARIFF",
                            }
                        ]
                    }
                },
            )
        },
    )


def test_contract_assertions_can_check_nested_response_lists() -> None:
    _assert_responses(
        "Record an audit trail for managed commercial changes",
        [
            {
                "action": "list_events",
                "path": "$.events.0.action",
                "json_equals": "ACTIVATED",
            },
            {
                "action": "list_events",
                "path": "$.events.0.snapshot.version",
                "json_equals": 2,
            },
        ],
        {
            "list_events": (
                200,
                {
                    "events": [
                        {
                            "action": "ACTIVATED",
                            "snapshot": {
                                "version": 2,
                            },
                        }
                    ]
                },
            )
        },
    )


def test_contract_assertions_can_compare_response_fields_to_saved_state() -> None:
    _assert_responses(
        "Persist quote lifecycle events in the outbox",
        [
            {
                "action": "list_created_events",
                "path": "$.events.0.aggregateId",
                "json_equals_state": "quote_id",
            },
        ],
        {
            "list_created_events": (
                200,
                {
                    "events": [
                        {
                            "aggregateId": "quote-123",
                        }
                    ]
                },
            )
        },
        {"quote_id": "quote-123"},
    )


def test_contract_assertions_fail_when_response_field_differs_from_saved_state() -> None:
    try:
        _assert_responses(
            "Persist quote lifecycle events in the outbox",
            [
                {
                    "action": "list_expired_events",
                    "path": "$.events.0.aggregateId",
                    "json_equals_state": "quote_id",
                },
            ],
            {
                "list_expired_events": (
                    200,
                    {
                        "events": [
                            {
                                "aggregateId": "other-quote",
                            }
                        ]
                    },
                )
            },
            {"quote_id": "quote-123"},
        )
    except ContractError as exception:
        assert "$.events.0.aggregateId was 'other-quote', expected saved state quote_id='quote-123'" in str(
            exception
        )
    else:
        raise AssertionError("expected saved-state assertion to fail")
