from __future__ import annotations

from collections.abc import Iterator

import pytest

from app import db
from app.db import Base
from app.models import Contract, ContractRateRule, EquipmentType, ExchangeRate, MarketRateSnapshot, PricingStrategyVersion, QuoteValidityPolicy, RateTable, SurchargeRule, SurchargeType
from app.seed import CONTRACT_RATE_RULE_ROWS, CONTRACT_ROWS, EXCHANGE_RATE_ROWS, MARKET_RATE_SNAPSHOT_ROWS, PRICING_STRATEGY_VERSION_ROWS, QUOTE_VALIDITY_POLICY_ROWS, RATE_TABLE_ROWS, SURCHARGE_RULE_ROWS, seed_reference_data


@pytest.fixture()
def sqlite_database(tmp_path, monkeypatch) -> Iterator[None]:
    database_path = tmp_path / "seed-test.sqlite"
    engine = db.create_engine(
        f"sqlite:///{database_path}",
        connect_args={"check_same_thread": False},
    )
    session_factory = db.sessionmaker(bind=engine, autoflush=False, autocommit=False)

    monkeypatch.setattr(db, "DATABASE_URL", f"sqlite:///{database_path}")
    monkeypatch.setattr(db, "engine", engine)
    monkeypatch.setattr(db, "SessionLocal", session_factory)
    monkeypatch.setattr("app.seed.SessionLocal", session_factory)

    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


def test_seed_reference_data_populates_rate_tables_and_surcharges(sqlite_database) -> None:
    seed_reference_data()

    with db.SessionLocal() as session:
        rate_rows = session.query(RateTable).order_by(RateTable.origin_port, RateTable.equipment_type).all()
        surcharge_rows = session.query(SurchargeRule).order_by(SurchargeRule.description).all()
        contract_rows = session.query(Contract).order_by(Contract.id).all()
        contract_rate_rows = session.query(ContractRateRule).order_by(ContractRateRule.contract_id).all()
        exchange_rate_rows = session.query(ExchangeRate).order_by(ExchangeRate.quote_currency).all()
        market_rate_rows = session.query(MarketRateSnapshot).order_by(MarketRateSnapshot.id).all()
        strategy_rows = session.query(PricingStrategyVersion).order_by(PricingStrategyVersion.id).all()
        validity_policy_rows = session.query(QuoteValidityPolicy).order_by(QuoteValidityPolicy.id).all()

    assert len(rate_rows) == len(RATE_TABLE_ROWS)
    assert len(surcharge_rows) == len(SURCHARGE_RULE_ROWS)
    assert len(contract_rows) == len(CONTRACT_ROWS)
    assert len(contract_rate_rows) == len(CONTRACT_RATE_RULE_ROWS)
    assert len(exchange_rate_rows) == len(EXCHANGE_RATE_ROWS)
    assert len(market_rate_rows) == len(MARKET_RATE_SNAPSHOT_ROWS)
    assert len(strategy_rows) == len(PRICING_STRATEGY_VERSION_ROWS)
    assert len(validity_policy_rows) == len(QUOTE_VALIDITY_POLICY_ROWS)
    assert {row.equipment_type for row in rate_rows} == set(EquipmentType)
    assert all(row.version == 1 for row in rate_rows)
    assert all(row.is_active for row in rate_rows)
    assert {row.surcharge_type for row in surcharge_rows} == {
        SurchargeType.BAF,
        SurchargeType.PORT_CONGESTION,
        SurchargeType.HEAVY_CARGO,
        SurchargeType.PEAK_SEASON,
    }
    assert all(row.version == 1 for row in surcharge_rows)
    assert all(row.is_active for row in surcharge_rows)


def test_seed_reference_data_is_idempotent(sqlite_database) -> None:
    seed_reference_data()
    seed_reference_data()

    with db.SessionLocal() as session:
        assert session.query(RateTable).count() == len(RATE_TABLE_ROWS)
        assert session.query(SurchargeRule).count() == len(SURCHARGE_RULE_ROWS)
        assert session.query(Contract).count() == len(CONTRACT_ROWS)
        assert session.query(ContractRateRule).count() == len(CONTRACT_RATE_RULE_ROWS)
        assert session.query(ExchangeRate).count() == len(EXCHANGE_RATE_ROWS)
        assert session.query(MarketRateSnapshot).count() == len(MARKET_RATE_SNAPSHOT_ROWS)
        assert session.query(PricingStrategyVersion).count() == len(PRICING_STRATEGY_VERSION_ROWS)
        assert session.query(QuoteValidityPolicy).count() == len(QUOTE_VALIDITY_POLICY_ROWS)
